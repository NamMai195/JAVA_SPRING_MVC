package vn.hoidanit.laptopshop;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaptopshopApplicationTests {

	@Test
	void contextLoads() {
	}

}
